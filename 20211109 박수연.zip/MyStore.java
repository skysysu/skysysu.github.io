package org.javaro.lecture;

public class MyStore {

}

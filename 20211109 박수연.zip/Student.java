package org.javaro.lecture;

public class Student {

}

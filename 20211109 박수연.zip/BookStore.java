package org.javaro.lecture;

public class BookStore {

}

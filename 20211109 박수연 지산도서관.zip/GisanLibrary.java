package org.javaro.lecture;
import org.javaro.lecture.Book;
import org.javaro.lecture.BookStore;
import org.javaro.lecture.Student;
class GisanLibrary {
	public static void main(String[] args) {
	//create a new GisanLibrary
		BookStore gisanLibrary = new BookStore("지산도서관");
		Book book1 = new Book("1","춘향전");
		Book book2 = new Book("2","홍길동전");
		Book book3 = new Book("3","심청전");
		Book book4 = new Book("4","전쟁과평화");
		Book book5 = new Book("5","논어");
		book1.setAuthor("미상"); book2.setAuthor("허균");
		book3.setAuthor("미상"); book4.setAuthor("레프 톨스토이");
		book1.setAuthor("공자");
		Student stud1 = new Student("202X1111");
		Student stud2 = new Student("202X2222");
		Student stud3 = new Student("202X3333");
		Student stud4 = new Student("202X4444");
		stud1.setName("홍길동"); stud2.setName("성춘향");
		stud3.setName("변학도"); stud4.setName("이몽룡");
		gisanLibrary.addBook(book1); gisanLibrary.addBook(book2);
		gisanLibrary.addBook(book3); gisanLibrary.addBook(book4);
		gisanLibrary.addStudent(stud1); gisanLibrary.addStudent(stud2);
		gisanLibrary.addStudent(stud3); gisanLibrary.addStudent(stud4);
		System.out.println("지산도서관 관리 시스템 생성");
		gisanLibrary.printStatus();
		System.out.println("book1 춘향전을 stud1 홍길동이 대출");
		gisanLibrary.checkOut(book1, stud1);
		gisanLibrary.printStatus();
		System.out.println("book3 심청전을 stud1 홍길동이 대출");
		gisanLibrary.checkOut(book3, stud1);
		gisanLibrary.printStatus();
		System.out.println("book3 심청전 반납");
		gisanLibrary.checkIn(book3);
		System.out.println("book3 심청전을 stud3 변학도가 대출");
		gisanLibrary.checkOut(book3, stud3);
		gisanLibrary.printStatus();
		System.out.println("book4 전쟁과평화를 stud2 성춘향이 대출");
		gisanLibrary.checkOut(book4, stud2);
		gisanLibrary.printStatus();
		System.out.println("book5 논어를 stud3 변학도가 대출");
		gisanLibrary.checkOut(book5, stud3);
		gisanLibrary.printStatus();
		System.out.println("book4 전쟁과평화 반납");
		gisanLibrary.checkIn(book4);
		
		gisanLibrary.printStatus();
	}
}
